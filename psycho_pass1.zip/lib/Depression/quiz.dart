import 'package:flutter/material.dart';
import 'package:psycho_pass/Depression/answer.dart';
import 'package:psycho_pass/Depression/question.dart';

import '../Anxiety/answer.dart';
import '../Anxiety/question.dart';

class QuizDepression extends StatelessWidget {
  final List<Map<String, Object>> questions;
  final int questionIndex;
  final Function answerQuestion;

  QuizDepression({
    @required this.questions,
    @required this.answerQuestion,
    @required this.questionIndex,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        QuestionDepression(
          questions[questionIndex]['questionText'],
        ), //Question
        ...(questions[questionIndex]['answers'] as List<Map<String, Object>>)
            .map((answer) {
          return AnswerDepression(() => answerQuestion(answer['score']), answer['text']);
        }).toList()
      ],
    ); //Column
  }
}