
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:psycho_pass/Depression/quiz.dart';
import 'package:psycho_pass/Depression/result.dart';
import 'package:psycho_pass/side-menu.dart';
import 'package:psycho_pass/src/loginPage.dart';

import '../Screens/ProfilePage.dart';
import '../anxiety_page.dart';
import '../Anxiety/quiz.dart';
import '../Anxiety/result.dart';

class DepressionTestPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _DepressionTestState();
  }
}

class _DepressionTestState extends State<DepressionTestPage>{
  final _questions = const [
    {
      'questionText': 'Q1. In the last month, how often have you been upset because of something that happened unexpectedly',
      'answers': [
        {'text': 'never', 'score': 2},
        {'text': 'almost never', 'score': 0},
        {'text': 'sometimes', 'score': 5},
        {'text': 'fairly often', 'score': 1},
        {'text': 'very often', 'score': 4},
      ],
    },
    {
      'questionText': 'Q2.  In the last month, how often have you felt that you were unable to control the important things in your life?',
      'answers': [
        {'text': 'never', 'score': 1},
        {'text': 'almost never', 'score': 2},
        {'text': 'sometimes', 'score': 0},
        {'text': 'fairly often', 'score': 5},
        {'text': 'very often', 'score': 3},
      ],
    },
    {
      'questionText': ' Q3.  In the last month, how often have you felt confident about your ability to handle your personal problems?',
      'answers': [
        {'text': 'never', 'score': 4},
        {'text': 'almost never', 'score': 2},
        {'text': 'sometimes', 'score': 3},
        {'text': 'fairly often', 'score': 0},
        {'text': 'very often', 'score': 1},
      ],
    },
    {
      'questionText': 'Q4. In the last month, how often have you felt that things were going your way?',
      'answers': [
        {'text': 'never', 'score': 2},
        {'text': 'almost never', 'score': 1},
        {'text': 'sometimes', 'score': 3},
        {'text': 'fairly often', 'score': 5},
        {'text': 'very often', 'score': 0},
      ],
    },
    {
      'questionText':
      'Q5. In the last month, how often have you found that you could not cope with all the things that you had to do?',
      'answers': [
        {'text': 'never', 'score': 1},
        {'text': 'almost never', 'score': 0},
        {'text': 'sometimes', 'score': 3},
        {'text': 'fairly often', 'score': 2},
        {'text': 'very often', 'score': 4},
      ],
    },
    {
      'questionText': 'Q6. In the last month, how often have you felt nervous and stressed?',
      'answers': [
        {'text': 'never', 'score': 0},
        {'text': 'almost never', 'score': 2},
        {'text': 'sometimes', 'score': 6},
        {'text': 'fairly often', 'score': 3},
        {'text': 'very often', 'score': 1},
      ],
    },
    {
      'questionText': 'Q7.In the last month, how often have you been able to control irritations in your life?',
      'answers': [
        {'text': 'never', 'score': 2},
        {'text': 'almost never', 'score': 5},
        {'text': 'sometimes', 'score': 15},
        {'text': 'fairly often', 'score': 3},
        {'text': 'very often', 'score': 0},
      ],
    },
  ];

  var _questionIndex = 0;
  var _totalScore = 0;

  void _resetQuiz() {
    setState(() {
      _questionIndex = 0;
      _totalScore = 0;
    });
  }

  void _answerQuestion(int score) {
//    _totalScore += score;

    setState(() {
      _questionIndex = _questionIndex + 1;
    });
    print(_questionIndex);
    if (_questionIndex < _questions.length) {
      print('We have more questions!');
    } else {
      print('No more questions!');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Depression'),
          backgroundColor: Colors.blue,
          elevation: defaultTargetPlatform == TargetPlatform.android ? 5.0:0.0,
          actions: <Widget>[
            InkWell(
              onTap: ()=>  Navigator.push(
                  context, MaterialPageRoute(builder: (context) => AnxietyPage())),
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Row(
                  children: <Widget>[

                  ],
                ),
              ),
            ),
          ],
        ),
        body: new SingleChildScrollView(
          child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  _questionIndex < _questions.length
                      ? QuizDepression(
                    answerQuestion: _answerQuestion,
                    questionIndex: _questionIndex,
                    questions: _questions,
                  ) //Quiz
                      : ResultDepression(_totalScore, _resetQuiz),
//                   : ResultDepression(_totalScore, _resetQuiz, ),
                ],
              )
          ),
        )
//      floatingActionButton: new FloatingActionButton.extended(
//        onPressed: () {
//      Navigator.push(
//          context, MaterialPageRoute(builder: (context) => AnxietyTestPage()));
//    },
//        label: Text("Next"),
//                    elevation: 2.0,
//            icon: new Icon(Icons.arrow_forward),
//            backgroundColor: new Color(0xFFE0A82E6),
//      ),
//        floatingActionButton: new FloatingActionButton.extended(
//            elevation: 2.0,
//            icon: new Icon(Icons.arrow_forward),
//            backgroundColor: new Color(0xFFE0A82E6),
//            onPressed: (){

//        )
      ); //Scaffold//MaterialApp
  }


}
//    body:new Center(
//        child:new Text('Home Page')
//    ),
//  );
//}