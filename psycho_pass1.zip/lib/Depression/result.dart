import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;

class ResultDepression extends StatefulWidget {
  final int resultScore;
  final Function resetHandler;

  ResultDepression(this.resultScore, this.resetHandler);

  @override
  _ResultDepressionState createState() => _ResultDepressionState();
}

class _ResultDepressionState extends State<ResultDepression> {
  static var chartdisplay;

  _ResultDepressionState();

  void initState(){
    setState(() {
      var data = [
        Sales("Q1", 10),
        Sales("Q2", 30),
        Sales("Q3", 20),
        Sales("Q4", 15),
        Sales("Q5", 50),
        Sales("Q6", 45),
        Sales("Q7", 32),
      ];
      var series = [
        charts.Series(
        domainFn: (Sales sales,_) => sales.label,
        measureFn: (Sales sales,_) => sales.value,
        id: "Sales",
        data: data,
        fillColorFn: (Sales sales, _) {
          return charts.MaterialPalette.blue.shadeDefault;
        },
      ),
      ];
      chartdisplay = charts.BarChart(
          series,
        animate: true,
        vertical: true,
        barGroupingType: charts.BarGroupingType.grouped,
        defaultRenderer: charts.BarRendererConfig(
          groupingType: charts.BarGroupingType.grouped,
          strokeWidthPx: 1.0,
        ),
        domainAxis: charts.OrdinalAxisSpec(
          renderSpec: charts.NoneRenderSpec(),
        ),
      );
    });
  }
  String get resultPhrase {
    String resultText;
    if (widget.resultScore >= 36) {
      resultText = 'Highly perceived depression please concern with doctor!';
      print(widget.resultScore);
    } else if (widget.resultScore >= 22 && widget.resultScore <= 35) {
      resultText = ' Moderate depression please concern with doctor!';
      print(widget.resultScore);
    } else if (widget.resultScore >= 0 && widget.resultScore <= 21) {
      resultText = 'Low depression its ok!';
    } else {
      resultText = 'This is a poor score!';
      print(widget.resultScore);
    }
    return resultText;
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: [
          Container(
            height: MediaQuery.of(context).size.height*0.50,
            child: chartdisplay,
          ),
          Padding(
            padding: EdgeInsets.all(20,),
            child: Text(resultPhrase, style: TextStyle(fontWeight: FontWeight.bold),),
          ),
          FlatButton(
            child: Text(
              'Restart for testing!', style: TextStyle(color: Colors.blue,fontSize: 17, fontWeight: FontWeight.bold),
            ), //Text

            onPressed: widget.resetHandler,
          ), //FlatButton
        ],
      )
    ); //Center
  }
//  chartdisplay() {
//    return charts.BarChart(
//      seriesList,
//      animate: true,
//      vertical: false,
//      barGroupingType: charts.BarGroupingType.grouped,
//      defaultRenderer: charts.BarRendererConfig(
//        groupingType: charts.BarGroupingType.grouped,
//        strokeWidthPx: 1.0,
//      ),
//      domainAxis: charts.OrdinalAxisSpec(
//        renderSpec: charts.NoneRenderSpec(),
//      ),
//    );
//  }
}
class Sales {
  final String label;
  final int value;

  Sales(this.label, this.value);
}
//mainAxisAlignment: MainAxisAlignment.center,
//children: <Widget>[
//chartdisplay,
////          Text(
////           " resultPhrase",
////            style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.blue),
////            textAlign: TextAlign.center,
////          ), //Text
////          Text(
//////              '${widget.resultScore}
////            'Score 10',
////            style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold),
////            textAlign: TextAlign.center,
////          ), //Text

//], //<Widget>[]
//),
//), //Column