import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:psycho_pass/SharedPreference/AppSharedPreference.dart';
import 'package:psycho_pass/Singleton/Singleton.dart';
import 'package:psycho_pass/depression_page.dart';
import 'package:psycho_pass/doctor_login/create_ques.dart';
import 'package:psycho_pass/doctor_login/loginPage.dart';
import 'package:psycho_pass/doctor_login/profiledoctor.dart';
import 'package:psycho_pass/help/help.dart';
import 'package:psycho_pass/models/AppUser.dart';
import 'package:psycho_pass/questioning_page.dart';
import 'package:psycho_pass/setting_menu.dart';
import 'package:psycho_pass/src/Feedback.dart';
import 'package:psycho_pass/src/loginPage.dart';
import 'package:psycho_pass/CardItemModel.dart';
import 'package:psycho_pass/stress_page.dart';
import 'package:quick_feedback/quick_feedback.dart';
import 'package:psycho_pass/animate/colors.dart';
import 'package:psycho_pass/animate/constant.dart';
import 'package:psycho_pass/animate/destinationDetail.dart';
import 'package:psycho_pass/animate/style.dart';

import '../anxiety_page.dart';

class DoctorMenu extends StatefulWidget {
  static final id = '/doctor-menu';
  // final String emailcontroller;
  // final String namecontroller;
  final String uid;

  DoctorMenu({Key key, this.uid}) : super(key: key);
  @override
  _DoctorMenuState createState() => new _DoctorMenuState();
}

class _DoctorMenuState extends State<DoctorMenu> with TickerProviderStateMixin{
  var appColors = [Color.fromRGBO(10, 130, 230, 1.0),Color.fromRGBO(10, 130, 230, 1.0),Color.fromRGBO(10, 130, 230, 1.0), Color.fromRGBO(10, 130, 230, 1.0)];
  var currentRouter = {'value1': AnxietyPage(), 'value2': StressPage(), 'value3': DepressionPage(), 'value4': QuestioningPage()};
  var cardouter = 0;
  var cardIndex = 0;
  ScrollController scrollController;
  var currentColor = Color.fromRGBO(10, 130, 230, 1.0);
  var result;

  final AppUser user = Singleton.user;

  var cardsList = [CardItemModel("Anxiety", Icons.account_circle, 9, 0.83),CardItemModel("Stress", Icons.work, 12, 0.24),CardItemModel("Depression", Icons.home, 7, 0.32),CardItemModel("Questioning", Icons.circle, 7, 0.32)];
  // final emailcontroller;
  // final namecontroller;
  // final uid;
  AnimationController animationController;
  ColorTween colorTween;
  CurvedAnimation curvedAnimation;
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final _auth = FirebaseAuth.instance;
  bool showProgress = false;

  // _MenuPageState(this.emailcontroller, this.namecontroller, this.uid);
  @override
  void initState() {
    super.initState();
    Firebase.initializeApp();
    scrollController = new ScrollController();
    // this.emailcontroller;
    // this.namecontroller;
  }
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text("Psycho Pass", style: TextStyle(fontSize: 16.0),),
        backgroundColor: currentColor,
        centerTitle: true,
        actions: <Widget>[
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: InkWell(
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 12),
                  child: Row(
                    children: <Widget>[
                      Container(
                        padding: EdgeInsets.only(left: 0, top: 10, bottom: 10),
                        child: Icon(Icons.logout, color: Colors.white),
                      ),
                    ],
                  ),
                ),
                onTap: (){
                  FirebaseAuth auth = FirebaseAuth.instance;
                  auth.signOut().then((res) {
                    Fluttertoast.showToast(
                        msg: "Signed out",
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.BOTTOM,
                        timeInSecForIosWeb: 1,
                        backgroundColor: Colors.blueAccent,
                        textColor: Colors.white,
                        fontSize: 16.0);
                    Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(builder: (context) => DoctorLogin()),
                            (Route<dynamic> route) => false);
                  });
                }
            ),
          ),
        ],
        elevation: 0.0,
      ),
      body:new Container(
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppColor.secondaryColor,
              AppColor.secondaryColor,
            ],
          ),
        ),
        child: ListView(
          children: [
            customAppBar(),
            SizedBox(
                height: 400,
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Hi Dr."+user.name ,style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 22,),textAlign: TextAlign.left,),
                      Text("Welcome to our Psychology App", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 22),),
                    ],
                  ),
                )
            ),


          ],
        ),
      ),
      drawer: new Drawer(
        child: new ListView(
          padding: const EdgeInsets.all(0.0),
          children: <Widget>[
            new UserAccountsDrawerHeader(accountName: new Text("Dr."+user.name, style: TextStyle(fontSize: 18)), accountEmail: new Text(user.email,style: TextStyle(fontSize: 18)), currentAccountPicture: new CircleAvatar(
              backgroundColor:Colors.blue,
            )),
            new ListTile(
                title:new Text('Profile'),
                onTap: () async {
                  print("Print");
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => DoctorProfile(uid: widget.uid, name: user.name, email: user.email, phone: user.phone,)),
                  );
                }
            ),
            new ListTile(
                title:new Text('Create Question'),
                onTap: () async {
                  print("Print");
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => createQuestion(uid: widget.uid, name: user.name,)),
                  );
                }
            ),
          ],
        ),
      ),
    );
  }
  Widget hotDestinationCard( String currentRouter,
      BuildContext context,int index) {
    return GestureDetector(
      onTap: () => {
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => DestinationDetail(currentRouter,index)),

        )
      },
      child: Stack(children: [
        Hero(
          tag: currentRouter,
          child: Container(
            height: 200,
            width: 140,
            margin: EdgeInsets.only(right: 25),
            padding: EdgeInsets.only(bottom: 20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(25),

            ),
          ),
        ),
        Positioned(
          top: 0,
          left: 0,
          child: Container(
            height: 200,
            width: 140,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(25),
              gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [AppColor.white, Colors.white]),
            ),
          ),
        ),
        Positioned(
          bottom: 20,
          left: 20,
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                PrimaryText(
                    color: Colors.blue,
                    text: currentRouter,
                    size: 20,
                    fontWeight: FontWeight.w800),
              ]),
        ),
      ]),
    );
  }
  Padding customAppBar() {
    return Padding(
      padding: const EdgeInsets.only(top: 60, left: 25, right: 25, bottom: 50),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
//          PrimaryText(
//            text: 'Destination',
//            size: 32,
//            fontWeight: FontWeight.w700,
//          ),
//          RawMaterialButton(
//            constraints: BoxConstraints(minWidth: 0),
//            onPressed: null,
//            elevation: 2.0,
//            fillColor: Colors.white10,
//            padding: EdgeInsets.all(8),
//            child: Icon(Icons.search_rounded,
//                color: AppColor.primaryColor, size: 30),
//            shape: CircleBorder(),
//          )
        ],
      ),
    );
  }
// void _showFeedback(context) {
//   showDialog(
//     context: context,
//     builder: (context) {
//       return QuickFeedback(
//         title: 'Leave a feedback', // Title of dialog
//         showTextBox: true, // default false
//         textBoxHint:
//         'Share your feedback', // Feedback text field hint text default: Tell us more
//         submitText: 'SUBMIT', // submit button text default: SUBMIT
//         onSubmitCallback: (feedback) {
//           print('$feedback'); // map { rating: 2, feedback: 'some feedback' }
//           Navigator.of(context).pop();
//         },
//         askLaterText: 'ASK LATER',
//         onAskLaterCallback: () {
//           print('Do something on ask later click');
//         },
//       );
//     },
//   );
// }
}