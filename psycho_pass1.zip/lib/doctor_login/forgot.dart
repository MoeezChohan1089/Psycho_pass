import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:psycho_pass/doctor_login/loginPage.dart';
import 'package:psycho_pass/src/ParseUser.dart';
import 'package:psycho_pass/src/signup.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'Widget/bezierContainer.dart';
// EXTERNAL WIDGET
import 'package:psycho_pass/Utils/CircularLogo.dart';
import 'package:psycho_pass/Utils/forgotFields.dart';
import 'package:psycho_pass/src/loginPage.dart';

class ForgotPasswordDoctor extends StatefulWidget {
  // STATIC ID
  static final id = '/forgotpassword';

  @override
  _ForgotPasswordDoctorState createState() => _ForgotPasswordDoctorState();
}

class _ForgotPasswordDoctorState extends State<ForgotPasswordDoctor> {
  // Global Form Key
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  // AutoValidate To False
  bool _autoValidate = false;

  // Map -> contains the Input Validated Values, values shown in print after submit
  Map<dynamic, dynamic> keyValues = {};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Forgot Password",
        ),
        backgroundColor: Colors.blue,
      ),
      body: Container(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.only(top:50, bottom: 70),
                child: Image.asset(
                  'images/logo.png',
                  width: 150.0,
                  height: 120.0,
                  fit: BoxFit.cover,
                ),
              ),
              // Form
              Form(
                key: _formKey,
                autovalidate: _autoValidate,
                child: ForgotFields(
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Validate Inputs
  void _validateInputs() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      print(keyValues);
      Navigator.pushNamed(context, DoctorLogin.id);
    } else {
      setState(() {
        _autoValidate = true;
      });
    }
  }
  // void doUserResetPassword() async {
  //   var controllerEmail;
  //   final ParseUser user = ParseUser(null, null, controllerEmail.text.trim());
  //   final ParseResponse parseResponse = await user.requestPasswordReset();
  //   if (parseResponse.success) {
  //     Fluttertoast.showToast(
  //         msg: "Your Email has been sent",
  //         toastLength: Toast.LENGTH_SHORT,
  //         gravity: ToastGravity.BOTTOM,
  //         timeInSecForIosWeb: 1,
  //         backgroundColor: Colors.blueAccent,
  //         textColor: Colors.white,
  //         fontSize: 16.0);
  //   } else {
  //     Fluttertoast.showToast(
  //         msg: "Invalid email and password",
  //         toastLength: Toast.LENGTH_SHORT,
  //         gravity: ToastGravity.BOTTOM,
  //         timeInSecForIosWeb: 1,
  //         backgroundColor: Colors.blueAccent,
  //         textColor: Colors.white,
  //         fontSize: 16.0);
  //   }
  // }
  // Add Values In Map
  void _addValuesInMap(String val) {
    keyValues[val] = val;
  }
} // End Of Class
