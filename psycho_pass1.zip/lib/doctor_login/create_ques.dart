import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:psycho_pass/Singleton/Singleton.dart';
import 'package:psycho_pass/src/FirebaseDatabase.dart';

class createQuestion extends StatefulWidget {
  final uid;
  final String name;

  const createQuestion({Key key, this.uid, this.name}) : super(key: key);
  @override
  _createQuestionState createState() => _createQuestionState(uid);
}

class _createQuestionState extends State<createQuestion> {
  final uid;
  FirebaseAuth firebaseAuth = FirebaseAuth.instance;
  DatabaseReference dbRef =
  FirebaseDatabase.instance.reference().child("Users");
  TextEditingController questionController = TextEditingController();
  final _auth = FirebaseAuth.instance;
  FireBaseutilss _fireBaseutils = new FireBaseutilss();
  bool _success;
  bool isVisible = false;
  _createQuestionState(this.uid);

  @override
  void initState() {
    super.initState();
    Firebase.initializeApp();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Create Question',),
          toolbarHeight: 80,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(30),
            ),
          ),
        ),
        body: Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.all(20),
                  child: TextField(
                    controller: questionController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(25.0),
                      ),
                      labelText: 'Write your own question...',
                    ),
                  ),
                ),

                RaisedButton(
                  padding: EdgeInsets.only(
                      left: 40, right: 40, top: 15, bottom: 15),
                  textColor: Colors.white,
                  highlightElevation: 10,
                  color: Colors.blue,
                  child: Text('Next'),
                  onPressed: () {
                    Create_question();
                    return showDialog(
                      context: context,
                      builder: (context) {
                        return AlertDialog(
                          title: Text("Your Question has been created"),
                          // Retrieve the text which the user has entered by
                          // using the TextEditingController.
                          content: Text("Q:" + questionController.text),
                          actions: <Widget>[
                            new FlatButton(
                              child: new Text('OK'),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            )
                          ],
                        );
                      },
                    );
                  },
                )
              ],
            )
        )
    );
  }

  void Create_question() async {
    if (isInputsValid()) {
      setState(() {
        isVisible = true;
      });
      print(questionController.text);
      _fireBaseutils.writeMessage("Doctor Questions", questionController.text);
    }
        }
  bool isInputsValid() {
    return (questionController.value.text.trim().toString().isNotEmpty);
  }
}