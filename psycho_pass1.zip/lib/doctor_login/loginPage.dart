import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:psycho_pass/SharedPreference/AppSharedPreference.dart';
import 'package:psycho_pass/Singleton/Singleton.dart';
import 'package:psycho_pass/doctor_login/doctormenu.dart';
import 'package:psycho_pass/doctor_login/forgot.dart';
import 'package:psycho_pass/doctor_login/signup.dart';
import 'package:psycho_pass/models/AppUser.dart';
import 'package:psycho_pass/src/signup.dart';
import 'package:psycho_pass/src/welcomePage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../side-menu.dart';
import 'Widget/bezierContainer.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:psycho_pass/Utils/SignInFields.dart';

class DoctorLogin extends StatefulWidget {
  static final id = '/';
  DoctorLogin({Key key, this.title, this.uid}) : super(key: key);

  final String title;
  final String uid;

  @override
  _DoctorLoginState createState() => _DoctorLoginState(uid);
}

class _DoctorLoginState extends State<DoctorLogin> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _autoValidate = false;
  final uid;
  final _auth = FirebaseAuth.instance;
  bool showProgress = false;

  _DoctorLoginState(this.uid);
  Map<dynamic, dynamic> keyValues = {};

  @override

  Widget _entryField(

    String title,
    TextEditingController controller, {
    bool isPassword = false, GlobalKey<FormState> key, bool autovalidate, void Function(String val) addValuesInMap, void Function() validateInputs,

  }) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            title,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
          ),
          SizedBox(
            height: 10,
          ),
          TextField(
              keyboardType: TextInputType.emailAddress,
              obscureText: isPassword,
              controller: controller,
              decoration: InputDecoration(
                  border: InputBorder.none,
                  fillColor: Color(0xfff3f3f4),
                  filled: true)),
        ],
      ),
    );
  }

  //  RaisedButton() {
  //   return Container(
  //     width: MediaQuery.of(context).size.width,
  //     padding: EdgeInsets.symmetric(vertical: 15),
  //     alignment: Alignment.center,
  //     decoration: BoxDecoration(
  //         borderRadius: BorderRadius.all(Radius.circular(5)),
  //         boxShadow: <BoxShadow>[
  //           BoxShadow(
  //               color: Colors.grey.shade200,
  //               offset: Offset(2, 4),
  //               blurRadius: 5,
  //               spreadRadius: 2)
  //         ],
  //         gradient: LinearGradient(
  //             begin: Alignment.centerLeft,
  //             end: Alignment.centerRight,
  //             colors: [Color(0xfff0876d4), Color(0xfff0876d4)])),
  //     child: Text(
  //       'Login',
  //       style: TextStyle(fontSize: 20, color: Colors.white),
  //     ),
  //   );
  //
  // }

  Widget _createAccountLabel() {
    return InkWell(
      onTap: () {
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => DoctorSignUp()));
      },
      child: Container(
//        margin: EdgeInsets.symmetric(vertical: 10),
//        padding: EdgeInsets.all(15),
        alignment: Alignment.bottomCenter,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Don\'t have an account ?',
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
            ),
            SizedBox(
              width: 10,
            ),
            Text(
              'Register',
              style: TextStyle(
                  color: Color(0xfff0876d4),
                  fontSize: 13,
                  fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }

  Widget _emailPasswordWidget() {
    return Column(
      children: <Widget>[
        _entryField("Doctor Email", _emailController,  key: _formKey, autovalidate: _autoValidate, validateInputs: this._validateInputs, addValuesInMap: this._addValuesInMap,),
        _entryField(
          "Password",
          _passwordController,
          isPassword: true,
          key: _formKey,
          autovalidate: _autoValidate,
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return Scaffold(
        body: Container(
      height: height,
      child:Stack(
        children: <Widget>[
          Positioned(
              top: -height * .15,
              right: -MediaQuery.of(context).size.width * .4,
              child: BezierContainer()),
          if (showProgress)
            Center(
              child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: 50,
                      width: 50,
                      child: CircularProgressIndicator(),
                    ),
                  ],
                ),
              ),
            )
          else
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(height: height * .2),
                    Image.asset(
                      'images/logo.png',
                      width: 150.0,
                      height: 120.0,
                      fit: BoxFit.cover,
                    ),
                    SizedBox(height: 50),
                    _emailPasswordWidget(),
                    SizedBox(height: 20),
                    Container(
                      padding: EdgeInsets.symmetric(vertical: 6),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(5)),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                                color: Colors.grey.shade200,
                                offset: Offset(2, 4),
                                blurRadius: 5,
                                spreadRadius: 2)
                          ],
                          gradient: LinearGradient(
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                              colors: [
                                Color(0xfff0876d4),
                                Color(0xfff0876d4)
                              ])),
                      child: FlatButton(
                        child: Text(
                          'Login',
                          style: TextStyle(fontSize: 18.0, color: Colors.white),
                        ),
                        onPressed: () async {
                          String email =
                              _emailController.value.text.trim().toString();
                          String password =
                              _passwordController.value.text.trim().toString();
                          setState(() {
                            showProgress = true;
                          });
                          try {
                            final UserCredential newUser =
                                await _auth.signInWithEmailAndPassword(
                                    email: email, password: password);
                            print(newUser.toString());

                            await FirebaseDatabase.instance
                                .reference()
                                .child("Users")
                                .child(newUser.user.uid)
                                .once()
                                .then((value) async {
                              print('${value.value['name']}');
                              print('${value.value['email']}');
                              print('${value.value['phone']}');
                              print('${value.value['pin']}');
                              print('${value.value['state']}');
                              print('${value.key}');
                              AppUser user = new AppUser(
                                name: value.value['name'],
                                email: value.value['email'],
                                phone: value.value['phone'],
                                pin: value.value['pin'],
                                state: value.value['state'],
                                id: value.key,
                              );
                              Singleton.user = user;
                              await AppSharedPref.saveUser('user', user, 'doctor');
                            });

                            if (newUser != null) {
                              Fluttertoast.showToast(
                                  msg: "Login Successfully",
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.BOTTOM,
                                  timeInSecForIosWeb: 1,
                                  backgroundColor: Colors.blueAccent,
                                  textColor: Colors.white,
                                  fontSize: 16.0);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => DoctorMenu()),
                              );
                              setState(() {
                                showProgress = false;
                              });
                            }
                          } catch (e) {
                            Fluttertoast.showToast(
                                msg: "Invalid email and password",
                                toastLength: Toast.LENGTH_SHORT,
                                gravity: ToastGravity.BOTTOM,
                                timeInSecForIosWeb: 1,
                                backgroundColor: Colors.blueAccent,
                                textColor: Colors.white,
                                fontSize: 16.0);
                            setState(() {
                              showProgress = false;
                            });
                          }
                        },
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(vertical: 10),
                      alignment: Alignment.centerRight,
                      child: FlatButton(
                        child: Text(
                          'Forgot password?',
                          style: TextStyle(fontSize: 18.0, color: Colors.blue),
                        ),
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => ForgotPasswordDoctor()));
                        },
                      ),
                    ),
                    SizedBox(height: height * .055),
                    _createAccountLabel(),
                  ],
                ),
              ),
            ),
        ],
      ),
    ));
  }
  void _validateInputs() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      print(keyValues);
      Navigator.pushNamed(context, MenuPage.id);
    } else {
      setState(() {
        _autoValidate = true;
      });
    }
  }

  // Add Values In Map
  void _addValuesInMap(String val) {
    keyValues[val] = val;
  }

}
