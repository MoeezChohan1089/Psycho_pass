import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:psycho_pass/doctor_login/doctormenu.dart';
import 'package:psycho_pass/side-menu.dart';
import 'package:psycho_pass/src/welcomePage.dart';
import 'package:psycho_pass/Constant/Constant.dart';
import 'package:psycho_pass/Screens/SplashScreen.dart';
import 'package:psycho_pass/Screens/ProfilePage.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'login.dart';

// final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
// FlutterLocalNotificationsPlugin();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // var initializationSettingsAndroid =
  //   AndroidInitializationSettings('psycho_pass');
  //
  // var initializationSettingsIOS = IOSInitializationSettings(
  //   requestAlertPermission: true,
  //   requestBadgePermission: true,
  //   requestSoundPermission: true,
  //   onDidReceiveLocalNotification:
  //   (int id, String title, String body, String payload) async {});
  // var initializationSettings = InitializationSettings(
  //     initializationSettingsAndroid, initializationSettingsIOS);
  // await flutterLocalNotificationsPlugin.initialize(initializationSettings,
  // onSelectNotification: (String payload) async{
  //   if(payload != null){
  //     debugPrint('Notification Payload:' + payload);
  //   }
  // });
 await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatefulWidget {

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  FlutterLocalNotificationsPlugin localNotification;
  // static final String oneSignalAppID = '5612248a-490b-47d3-a193-988190071123';
  //
  Future _showNotification() async{
    var androidDetails = new AndroidNotificationDetails(
        "channelId",
        "Psycho_Pass",
        "if you are feeling any disease then for checking you can test our app.",
        importance: Importance.high);
    var IOSdetails = new IOSNotificationDetails();
    var generalNotificationDetails = new NotificationDetails(android: androidDetails, iOS: IOSdetails);
    await localNotification.show(0,  "Psycho_Pass",
        "if you want to check your any disease then here register yourself.",
        generalNotificationDetails);
  }

  @override
  void initState(){
    super.initState();
    var androidInitialize = new AndroidInitializationSettings('psycho_pass');
    var IOSInitialize = new IOSInitializationSettings();
    var initializationSettings = new InitializationSettings(
        android: androidInitialize, iOS: IOSInitialize);
    localNotification = new FlutterLocalNotificationsPlugin();
    localNotification.initialize(initializationSettings);
  }
  
  @override

  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        textTheme:GoogleFonts.latoTextTheme(textTheme).copyWith(
          bodyText1: GoogleFonts.montserrat(textStyle: textTheme.bodyText1),
        ),
      ),
      debugShowCheckedModeBanner: false,
      home: SplashScreen(),
      routes: <String, WidgetBuilder>{
        //SPLASH_SCREEN: (BuildContext context) => new MapScreen(),
        WELCOME: (BuildContext context) => new WelcomePage(),
        MENUPAGE: (BuildContext context) => new MenuPage(),
        DOCTORMENU: (BuildContext context) => new DoctorMenu(),
      },
    );
  }

  // Future<void> initPlatformState() async{
  //   OneSignal.shared.init(
  //       oneSignalAppID,
  //   );
  //   OneSignal.shared.setInFocusDisplayType(OSNotificationDisplayType.notification);
  // }
}
