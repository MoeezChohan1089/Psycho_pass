import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:psycho_pass/Anxiety/anxiety_test.dart';
import 'package:psycho_pass/Depression/depression_test.dart';
import 'package:psycho_pass/List.dart';
import 'package:psycho_pass/Questioning/questioning_test.dart';
import 'package:psycho_pass/Stress/stress_test.dart';
import 'package:psycho_pass/animate/colors.dart';
import 'package:psycho_pass/animate/style.dart';
import 'package:psycho_pass/anxiety_page.dart';

import '../depression_page.dart';
import '../questioning_page.dart';
import '../side-menu.dart';
import '../stress_page.dart';

class DestinationDetail extends StatefulWidget {
  final String placeName;
  final int index;
  const DestinationDetail(this.placeName,this.index);

  @override
  _DestinationDetailState createState() => _DestinationDetailState(index);
}

class _DestinationDetailState extends State<DestinationDetail> with SingleTickerProviderStateMixin {
  AnimationController _controller;
  final index;
  _DestinationDetailState(this.index);
  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this,
    );
    _controller.forward();
  }
  @override
  Widget build(BuildContext context) {
    return DestinationPage(
      controller: _controller,
      placeName: widget.placeName,
      index: index,
    );
  }
}

class DestinationPage extends StatelessWidget {
  final placeName;
  final currentRouter = [MaterialPageRoute(builder: (context) => AnxietyTestPage()), MaterialPageRoute(builder: (context) => StressTestPage()), MaterialPageRoute(builder: (context) => DepressionTestPage()), MaterialPageRoute(builder: (context) => listpage())];
  final int index;
  DestinationPage(
      {Key key, @required AnimationController controller, this.placeName,this.index})
      : animation = DestinationPageEnterAnimation(controller),
        super(key: key);
  final DestinationPageEnterAnimation animation;

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
            appBar: new AppBar(
              backgroundColor: Colors.blue,
              title: new Text(placeName),
              elevation: defaultTargetPlatform == TargetPlatform.android ? 5.0:0.0,
              actions: <Widget>[
                InkWell(
                  onTap: ()=>  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => MenuPage())),
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 12),
                    child: Row(
                      children: <Widget>[

                      ],
                    ),
                  ),
                ),
              ],
            ),
            body: new Center(
                child:new Text("Start your Test For "+ placeName, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22),)
            ),
            floatingActionButton: new FloatingActionButton(
                elevation: 2.0,
                child: new Icon(Icons.arrow_forward),
                backgroundColor: new Color(0xFFE0A82E6),
                onPressed: (){
                  Navigator.push(
                      context, currentRouter[index]);
                }
            )
    );

  }


  Widget hotDestinationCard(String placeName,
      BuildContext context) {
    return GestureDetector(
      onTap: () => {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => DestinationDetail(placeName,index)))
      },
      child: Stack(children: [
        Container(
          height: 160,
          width: 160,
          margin: EdgeInsets.only(right: 25),
          padding: EdgeInsets.only(bottom: 20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(25),
          ),
        ),
        Positioned(
          top: 0,
          left: 0,
          child: Container(
            height: 160,
            width: 160,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(25),
              gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [AppColor.secondaryColor, Colors.transparent]),
            ),
          ),
        ),
      ]),
    );
  }
}

class DestinationPageEnterAnimation {
  DestinationPageEnterAnimation(this.controller)
       : barHeight = Tween<double>(begin: 0, end: 600).animate(
          CurvedAnimation(
            parent: controller,
            curve: Interval(0, 0.5),
          ),
        );

  final AnimationController controller;
  final Animation<double> barHeight;
}
