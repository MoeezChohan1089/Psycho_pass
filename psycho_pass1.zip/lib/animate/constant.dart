//const destination = [
//  {
//    'placeNamee': 'Anxiety'
//  },
//  {
//    'placeNamee': 'Stress'
//  },
//  {
//    'placeNamee': 'Depression'
//  },
//  {
//    'placeNamee': 'Questioning'
//  },
//];

import 'package:flutter/material.dart';

const hotDestination = [
  {
    'placeName': 'Anxiety'
  },
  {
    'placeName': 'Stress',
  },
  {
    'placeName': 'Depression',
  },
  {
    'placeName': 'Questioning',
  },
  
];

