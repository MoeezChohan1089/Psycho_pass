import 'dart:async';
import 'dart:convert';

import 'package:psycho_pass/Constant/Constant.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:psycho_pass/Singleton/Singleton.dart';
import 'package:psycho_pass/doctor_login/doctormenu.dart';
import 'package:psycho_pass/models/AppUser.dart';
import 'package:psycho_pass/side-menu.dart';
import 'package:psycho_pass/src/loginPage.dart';
import 'package:psycho_pass/src/welcomePage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:get/get.dart';

String finalEmail;
String role;

class SplashScreen extends StatefulWidget {
  @override
  SplashScreenState createState() => new SplashScreenState();
}

class SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  var _visible = true;

  AnimationController animationController;
  Animation<double> animation;

  startTime() async {
    var _duration = new Duration(seconds: 3);
    return new Timer(_duration, navigationPage);
  }

  Future getValidationData() async {
    final SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    var obtainedemail = sharedPreferences.getString('user');
    var roleLogined = sharedPreferences.getString('role');
    setState(() {
      finalEmail = obtainedemail;
      role = roleLogined;
    });
   if(finalEmail!= null){
     var userData = json.decode(finalEmail);
     AppUser tempUser = new AppUser(
       name: userData['names'],
       email: userData['email'],
       phone: userData['phone'],
       pin: userData['pin'],
       state: userData['state'],
     );
     Singleton.user = tempUser;
   }
    // print('in splashScreen: ${Singleton.user.name}');
    print(finalEmail);
  }

  void navigationPage() {
     // Navigator.of(context).pushReplacementNamed(WELCOME);
    if (finalEmail == null) {
      Navigator.of(context).pushReplacementNamed(WELCOME);
      // Get.to(LoginPage());
    } else {
      if (role == 'patient') {
        // Get.to(MENUPAGE);
        Navigator.of(context).pushReplacementNamed(MENUPAGE);
      } else {
        // Get.to(DOCTORMENU);
        Navigator.of(context).pushReplacementNamed(DOCTORMENU);
      }
    }
  }

  @override
  void initState() {
    getValidationData().whenComplete(() async {
      Timer(Duration(seconds: 3), () {
        // Get.to(finalEmail == null ?  LoginPage() : WelcomePage())
      });
    });
    super.initState();
    animationController = new AnimationController(vsync: this, duration: new Duration(seconds: 2));
    animation = new CurvedAnimation(parent: animationController, curve: Curves.easeOut);

    animation.addListener(() => this.setState(() {}));
    animationController.forward();

    setState(() {
      _visible = !_visible;
    });
    startTime();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue,
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          new Column(
            mainAxisAlignment: MainAxisAlignment.end,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[],
          ),
          new Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              new Image.asset(
                'images/logo.png',
                width: animation.value * 250,
                height: animation.value * 250,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
