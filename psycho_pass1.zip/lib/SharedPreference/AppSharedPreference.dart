import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class AppSharedPref {
  // All methods are async because these operations are asynchronous.

  // Read User object which was saved on User Login.
  // returns User object if has User data, otherwise returns null.
  // key is used to get the saved value, every value is saved against a key.
  static readUser(String key) async {
    final prefs = await SharedPreferences.getInstance();
    //json.decode to convert json string back to Json Object
    return json.decode(prefs.getString(key));
  }

  // Save the User object to App Sessions.
  // Save the user object against the provided key.
  // It will override the data if there is previous data saved against the same key.
  //key = 'user'
  static saveUser(String key, dynamic value, String role) async {
    final prefs = await SharedPreferences.getInstance();
    //We cannot save custom objects.
    //So json.encode is used to convert User Object to Json a string.
    prefs.setString(key, json.encode(value));
    prefs.setString('role', role);
  }

  // Remove the User object from the App Session.
  // And the new value will automatically becomes null.
  static removeUser(String key) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.remove(key);
  }
}
