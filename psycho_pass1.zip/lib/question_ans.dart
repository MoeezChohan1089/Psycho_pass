import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:psycho_pass/Singleton/Singleton.dart';

class ansQuestion extends StatefulWidget {
  final uid;
  final questions;
  const ansQuestion(this.questions,{Key key, this.uid}) : super(key: key);
  @override
  _ansQuestionState createState() => _ansQuestionState(uid);
}

class _ansQuestionState extends State<ansQuestion> {
  final uid;
  FirebaseAuth firebaseAuth = FirebaseAuth.instance;
  DatabaseReference dbRef =
  FirebaseDatabase.instance.reference().child("Users");
  TextEditingController questionController = TextEditingController();

  _ansQuestionState(this.uid);
  Map quest = {};
  List questKeys = [];
  @override
  void initState() {
    quest = widget.questions;
    questKeys = quest.keys.toList();
    super.initState();
    Firebase.initializeApp();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Question',)
        ),
        body: questKeys.length > 0 ? ListView.builder(
            itemCount: questKeys.length,
            itemBuilder: (BuildContext context,int index){
              print(quest[questKeys[index]]);
              return Container(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Padding(
                        padding: EdgeInsets.all(20),
                        child: Text("${index+1}: ${quest[questKeys[index]]['Question']}", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
                      ),
                      Padding(
                        padding: EdgeInsets.all(20),
                        child: TextField(
                          controller: questionController,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(25.0),
                            ),
                            hintText: 'Write your Answer...',
                          ),
                        ),
                      ),
                      // Row(
                      //   children: [
                      //     RaisedButton(
                      //       padding: EdgeInsets.only(
                      //           left: 40, right: 40, top: 15, bottom: 15),
                      //       textColor: Colors.white,
                      //       highlightElevation: 10,
                      //       color: Colors.blue,
                      //       child: Text('Next'),
                      //       onPressed: () {
                      //         // return showDialog(
                      //         //   context: context,
                      //         //   builder: (context) {
                      //         //     return AlertDialog(
                      //         //       title: Text("Your Question has been created"),
                      //         //       // Retrieve the text which the user has entered by
                      //         //       // using the TextEditingController.
                      //         //       content: Text("Q:" + questionController.text),
                      //         //       actions: <Widget>[
                      //         //         new FlatButton(
                      //         //           child: new Text('OK'),
                      //         //           onPressed: () {
                      //         //             Navigator.of(context).pop();
                      //         //           },
                      //         //         )
                      //         //       ],
                      //         //     );
                      //         //   },
                      //         // );
                      //       },
                      //     )
                      //   ],
                      // )
                    ],
                  )
              );
            }
        ):Container()
    );
  }
}