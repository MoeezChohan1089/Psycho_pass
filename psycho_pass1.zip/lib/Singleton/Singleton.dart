import 'package:psycho_pass/models/AppUser.dart';

class Singleton {
  static final Singleton _singleton = Singleton._internal();

  factory Singleton() {
    return _singleton;
  }

  Singleton._internal();

  // signed-in user we keep the information of currently signed-in user
  // throughout the app and is used to get the id of current signed-in user.
  //static User signedInUser;

 static String userId;

 static AppUser user;

 static AppUser1 user1;


}