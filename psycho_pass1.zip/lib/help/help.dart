import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:psycho_pass/side-menu.dart';

class helpPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text("Help"),
        actions: <Widget>[
          InkWell(
            onTap: () =>
                Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => MenuPage())),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: <Widget>[
                ],
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.all(5),
          child: Column(
            children: [
              ListTile(
                title: Text('Anxiety:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                subtitle: Text("Anxiety is your body's natural response to stress. It's a feeling of fear or apprehension about what's to come. The first day of school, going to a job interview, or giving a speech may cause most people to feel fearful and nervous.\n This type of anxiety may cause you to stop doing things you enjoy. In extreme cases, it may prevent you from entering an elevator, crossing the street, or even leaving your home. If left untreated, the anxiety will keep getting worse.", style: TextStyle(fontSize: 17),),
              ),
              ListTile(
                title: Text('Depression:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                subtitle: Text("Depression, also known as major depressive disorder, is a mood disorder that makes you feel constant sadness or lack of interest in life. \n Most people feel sad or depressed at times. It’s a normal reaction to loss or life's challenges. But when intense sadness, including feeling helpless, hopeless, and worthless lasts for many days to weeks and keeps you from living your life, it may be something more than sadness. You could have clinical depression, a treatable medical condition.", style: TextStyle(fontSize: 17),),
              ),
              ListTile(
                title: Text('Stress:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                subtitle: Text("Stress is our body’s response to pressure. Many different situations or life events can cause stress. It is often triggered when we experience something new, unexpected or that threatens our sense of self, or when we feel we have little control over a situation. \n We all deal with stress differently. Our ability to cope can depend on our genetics, early life events, personality and social and economic circumstances, \nWhen we encounter stress, our body produces stress hormones that trigger a fight or flight response and activate our immune system. This helps us respond quickly to dangerous situations,\n Sometimes, this stress response can be useful: it can help us push through fear or pain so we can run a marathon or deliver a speech, for example. Our stress hormones will usually go back to normal quickly once the stressful event is over, and there won’t be any lasting effects.", style: TextStyle(fontSize: 17),),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
