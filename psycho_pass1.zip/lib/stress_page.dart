
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:psycho_pass/side-menu.dart';
import 'package:psycho_pass/src/loginPage.dart';

import 'Anxiety/anxiety_test.dart';
import 'Screens/ProfilePage.dart';
import 'Stress/stress_test.dart';

class StressPage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        appBar: new AppBar(
          backgroundColor: Colors.blue,
          title: new Text("Stress"),
          elevation: defaultTargetPlatform == TargetPlatform.android ? 5.0:0.0,
          actions: <Widget>[
            InkWell(
              onTap: ()=>  Navigator.push(
                  context, MaterialPageRoute(builder: (context) => MenuPage())),
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Row(
                  children: <Widget>[

                  ],
                ),
              ),
            ),
          ],
        ),
        body:new Center(
            child:new Text('Stress Page')
        ),
        floatingActionButton: new FloatingActionButton(
            elevation: 2.0,
            child: new Icon(Icons.add),
            backgroundColor: new Color(0xFFE0A82E6),
            onPressed: (){
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => StressTestPage()));
            }
        )
    );
  }

}