String ANIMATED_SPLASH = '/SplashScreen',
    WELCOME = '/WelcomePage',
    LOGIN_SCREEN = '/LoginScreen',
    MENUPAGE = '/MenuPage',
    DOCTORMENU = '/DoctorMenu';
