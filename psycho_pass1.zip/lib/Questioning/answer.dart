import 'package:flutter/material.dart';

class AnswerQuestioning extends StatelessWidget {
  final Function selectHandler;
  final String answerText;

  AnswerQuestioning(this.selectHandler, this.answerText);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.only(left: 20, right: 20, top: 5, bottom: 5),
      child: RaisedButton(
        color: Color(0xFF0A82E6),
        padding: EdgeInsets.all(20),
        textColor: Colors.white,
        child: Text(answerText),
        onPressed: selectHandler,
        shape: new RoundedRectangleBorder(
          borderRadius: new BorderRadius.circular(30.0),
        ),
      ), //RaisedButton
    ); //Container
  }
}