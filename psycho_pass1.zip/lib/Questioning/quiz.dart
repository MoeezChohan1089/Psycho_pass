import 'package:flutter/material.dart';
import 'package:psycho_pass/Questioning/answer.dart';
import 'package:psycho_pass/Questioning/question.dart';

import '../Anxiety/answer.dart';
import '../Anxiety/question.dart';

class QuizQuestioning extends StatelessWidget {
  final List<Map<String, Object>> questions;
  final int questionIndex;
  final Function answerQuestion;

  QuizQuestioning({
    @required this.questions,
    @required this.answerQuestion,
    @required this.questionIndex,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        QuestionQuestioning(
          questions[questionIndex]['questionText'],
        ), //Question
        ...(questions[questionIndex]['answers'] as List<Map<String, Object>>)
            .map((answer) {
          return AnswerQuestioning(() => answerQuestion(answer['score']), answer['text']);
        }).toList()
      ],
    ); //Column
  }
}