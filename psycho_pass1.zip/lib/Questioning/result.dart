import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;

class ResultQuestioning extends StatefulWidget {
  final int resultScore;
  final Function resetHandler;

  ResultQuestioning(this.resultScore, this.resetHandler);

  @override
  _ResultQuestioningState createState() => _ResultQuestioningState();
}

class _ResultQuestioningState extends State<ResultQuestioning> {
  static var chartdisplay;

  void initState(){
    setState(() {
      var data = [
        Sales("mon", 140),
        Sales("tue", 10),
        Sales("wed", 70),
        Sales("thu", 10),
        Sales("fri", 110),
        Sales("sat", 70),
        Sales("sun", 40),
        Sales("sun", 40),
        Sales("sun", 40),
        Sales("sun", 40),
      ];
      var series = [
        charts.Series(
          domainFn: (Sales sales,_) => sales.label,
          measureFn: (Sales sales,_) => sales.value,
          id: "Sales",
          data: data,
          fillColorFn: (Sales sales, _) {
            return charts.MaterialPalette.blue.shadeDefault;
          },
        ),
      ];
      chartdisplay = charts.BarChart(
        series,
        animate: true,
        vertical: true,
        barGroupingType: charts.BarGroupingType.grouped,
        defaultRenderer: charts.BarRendererConfig(
          groupingType: charts.BarGroupingType.grouped,
          strokeWidthPx: 1.0,
        ),
        domainAxis: charts.OrdinalAxisSpec(
          renderSpec: charts.NoneRenderSpec(),
        ),
      );
    });
  }
  String get resultPhrase {
    String resultText;
    if (widget.resultScore >= 36) {
      resultText = 'Potentially concerning levels of anxiety!';
      print(widget.resultScore);
    } else if (widget.resultScore >= 22 && widget.resultScore <= 35) {
      resultText = ' Moderate anxiety';
      print(widget.resultScore);
    } else if (widget.resultScore >= 0 && widget.resultScore <= 21) {
      resultText = 'Low anxiety';
    } else {
      resultText = 'This is a poor score!';
      print(widget.resultScore);
    }
    return resultText;
  }

  @override
  Widget build(BuildContext context) {
    return Center(
        child: Column(
          children: [
            Container(
              height: MediaQuery.of(context).size.height*0.50,
              child: chartdisplay,
            ),
            FlatButton(
              child: Text(
                'Restart for testing!', style: TextStyle(color: Colors.blue,fontSize: 17, fontWeight: FontWeight.bold),
              ), //Text

              onPressed: widget.resetHandler,
            ), //FlatButton
          ],
        )
    ); //Center
  }
//  chartdisplay() {
//    return charts.BarChart(
//      seriesList,
//      animate: true,
//      vertical: false,
//      barGroupingType: charts.BarGroupingType.grouped,
//      defaultRenderer: charts.BarRendererConfig(
//        groupingType: charts.BarGroupingType.grouped,
//        strokeWidthPx: 1.0,
//      ),
//      domainAxis: charts.OrdinalAxisSpec(
//        renderSpec: charts.NoneRenderSpec(),
//      ),
//    );
//  }
}
class Sales {
  final String label;
  final int value;

  Sales(this.label, this.value);
}
//mainAxisAlignment: MainAxisAlignment.center,
//children: <Widget>[
//chartdisplay,
////          Text(
////           " resultPhrase",
////            style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.blue),
////            textAlign: TextAlign.center,
////          ), //Text
////          Text(
//////              '${widget.resultScore}
////            'Score 10',
////            style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold),
////            textAlign: TextAlign.center,
////          ), //Text

//], //<Widget>[]
//),
//), //Column