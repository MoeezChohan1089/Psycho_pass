import 'dart:convert';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:psycho_pass/Singleton/Singleton.dart';
import 'package:psycho_pass/Stress/quiz.dart';
import 'package:psycho_pass/Stress/result.dart';
import 'package:psycho_pass/models/AppUser.dart';
import 'package:psycho_pass/side-menu.dart';
import 'package:psycho_pass/src/loginPage.dart';

import '../Screens/ProfilePage.dart';
import '../anxiety_page.dart';
import '../Anxiety/quiz.dart';
import '../Anxiety/result.dart';

class AnxietyTestPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _AnxietyTestState();
  }
}

class _AnxietyTestState extends State<AnxietyTestPage>{
  final AppUser1 user1 = Singleton.user1;
  var databaseReference = FirebaseDatabase.instance.reference()
      .child("anxiety").get();
  int index;
  final _questions = const [
    {
      'questionText': '',
      'answers': [
        {'text': 'Mildly but it didn’t bother me much', 'score': 2},
        {'text': 'Moderately it wasn’t pleasant at times', 'score': 1},
        {'text': 'Severely it bothered me a lot', 'score': 5},
        {'text': 'Not At All', 'score': 3},
      ],
    },
    {
      'questionText': 'Q2. Unable to relax',
      'answers': [
        {'text': 'Mildly but it didn’t bother me much', 'score': 5},
        {'text': 'Moderately it wasn’t pleasant at times', 'score': 1},
        {'text': 'Severely it bothered me a lot', 'score': 2},
        {'text': 'Not At All', 'score': 4},
      ],
    },
    {
      'questionText': ' Q3. Heart pounding/racing',
      'answers': [
        {'text': 'Mildly but it didn’t bother me much', 'score': 0},
        {'text': 'Moderately it wasn’t pleasant at times', 'score': 1},
        {'text': 'Severely it bothered me a lot', 'score': -2},
        {'text': 'Not At All', 'score': 3},
      ],
    },
    {
      'questionText': 'Q4. Terrified or afraid',
      'answers': [
        {'text': 'Mildly but it didn’t bother me much', 'score': 1},
        {'text': 'Moderately it wasn’t pleasant at times', 'score': 3},
        {'text': 'Severely it bothered me a lot', 'score': 4},
        {'text': 'Not At All', 'score': 2},
      ],
    },
    {
      'questionText':
      'Q5. Feeling of choking',
      'answers': [
        {'text': 'Mildly but it didn’t bother me much', 'score': 5},
        {'text': 'Moderately it wasn’t pleasant at times', 'score': 2},
        {'text': 'Severely it bothered me a lot', 'score': 1},
        {'text': 'Not At All', 'score': 3},
      ],
    },
    {
      'questionText': 'Q6. Feeling of choking',
      'answers': [
        {'text': 'Mildly but it didn’t bother me much', 'score': 2},
        {'text': 'Moderately it wasn’t pleasant at times', 'score': 2},
        {'text': 'Severely it bothered me a lot', 'score': 6},
        {'text': 'Not At All', 'score': 3},
      ],
    },
    {
      'questionText': 'Q7.Fear of dying',
      'answers': [
        {'text': 'Mildly but it didn’t bother me much', 'score': 0},
        {'text': 'Moderately it wasn’t pleasant at times', 'score': 1},
        {'text': 'Severely it bothered me a lot', 'score': 5},
        {'text': 'Not At All', 'score': 2},
      ],
    },
    {
      'questionText': 'Q8. Difficulty in breathing',
      'answers': [
        {'text': 'Mildly but it didn’t bother me much', 'score': 4},
        {'text': 'Moderately it wasn’t pleasant at times', 'score': 5},
        {'text': 'Severely it bothered me a lot', 'score': 2},
        {'text': 'Not At All', 'score': 1},
      ],
    },
    {
      'questionText': 'Q9. Faint / lightheaded',
      'answers': [
        {'text': 'Mildly but it didn’t bother me much', 'score': 2},
        {'text': 'Moderately it wasn’t pleasant at times', 'score': 4},
        {'text': 'Severely it bothered me a lot', 'score': 0},
        {'text': 'Not At All', 'score': 3},
      ],
    },
    {
      'questionText': 'Q10. Hot/cold sweats',
      'answers': [
        {'text': 'Mildly but it didn’t bother me much', 'score': 3},
        {'text': 'Moderately it wasn’t pleasant at times', 'score': 0},
        {'text': 'Severely it bothered me a lot', 'score': 1},
        {'text': 'Not At All', 'score': 4},
      ],
    },
  ];

  var _questionIndex = 0;
  var _totalScore = 0;

  void _resetQuiz() {
    setState(() {
      _questionIndex = 0;
      _totalScore = 0;
    });
  }

  void _answerQuestion(int score) {
    _totalScore += score;

    setState(() {
       _questionIndex = _questionIndex + 1;
    });
    print(_questionIndex);
    if (_questionIndex < _questions.length) {
      print('We have more questions!');
    } else {
      print('No more questions!');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Anxiety'),
        backgroundColor: Colors.blue,
         elevation: defaultTargetPlatform == TargetPlatform.android ? 5.0:0.0,
        actions: <Widget>[
          InkWell(
            onTap: ()=>  Navigator.push(
                context, MaterialPageRoute(builder: (context) => AnxietyPage())),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: <Widget>[

                ],
              ),
            ),
          ),
        ],
      ),
      body: new SingleChildScrollView(
        child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                _questionIndex < _questions.length
                    ? QuizStress(
                  answerQuestion: _answerQuestion,
                  questionIndex: _questionIndex,
                  questions: _questions,
                ) //Quiz
                    : Result(_totalScore, _resetQuiz, ''),
              ],
            )
        ),
      )
//      floatingActionButton: new FloatingActionButton.extended(
//        onPressed: () {
//      Navigator.push(
//          context, MaterialPageRoute(builder: (context) => AnxietyTestPage()));
//    },
//        label: Text("Next"),
//                    elevation: 2.0,
//            icon: new Icon(Icons.arrow_forward),
//            backgroundColor: new Color(0xFFE0A82E6),
//      ),
//        floatingActionButton: new FloatingActionButton.extended(
//            elevation: 2.0,
//            icon: new Icon(Icons.arrow_forward),
//            backgroundColor: new Color(0xFFE0A82E6),
//            onPressed: (){

//        )
    ); //Scaffold//MaterialApp
  }
}
