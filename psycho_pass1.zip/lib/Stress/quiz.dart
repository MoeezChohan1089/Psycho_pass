import 'package:flutter/material.dart';
import 'package:psycho_pass/Stress/answer.dart';
import 'package:psycho_pass/Stress/question.dart';

import '../Anxiety/answer.dart';
import '../Anxiety/question.dart';

class QuizStress extends StatelessWidget {
  final List<Map<String, Object>> questions;
  final int questionIndex;
  final Function answerQuestion;

  QuizStress({
    @required this.questions,
    @required this.answerQuestion,
    @required this.questionIndex,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        QuestionStress(
          questions[questionIndex]['questionText'],
        ), //Question
        ...(questions[questionIndex]['answers'] as List<Map<String, Object>>)
            .map((answer) {
          return AnswerStress(() => answerQuestion(answer['score']), answer['text']);
        }).toList()
      ],
    ); //Column
  }
}