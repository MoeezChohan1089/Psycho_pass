import 'package:flutter/material.dart';
import 'package:psycho_pass/src/FirebaseDatabase.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';

class ResultStress extends StatelessWidget {
  final int resultScore;
  final Function resetHandler;

  ResultStress(this.resultScore, this.resetHandler);
  bool isVisible = false;
  FireBaseutilssocree _fireBaseutils = new FireBaseutilssocree();
  //Remark Logic
  String get resultPhrase {
    String resultText;
    if (resultScore >=27) {
      resultText = 'High Perceived Stress please concern with doctor!';
      print(resultScore);
    } else if (resultScore >= 14 && resultScore <= 26) {
      resultText = ' Moderate Stress please concern with doctor';
      print(resultScore);
    } else if (resultScore >= 0 && resultScore <= 13) {
      resultText = 'Low Stress its ok';
    } else {
      resultText = 'This is a poor score!';
      print(resultScore);
    }
    return resultText;
  }

  @override
  Widget build(BuildContext context) {
    print("result:$resultScore");
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Container(

            decoration: new BoxDecoration(
              color: Colors.green,
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.green,
                width: 0,
              ),

            ),
            margin: EdgeInsets.only(bottom: 10, left: 20),
            child: Row(
              children: [
                Text("Low Stress", style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 20)),
              ],
            ),
          ),
          Container(
            decoration: new BoxDecoration(
              color: Colors.blue,
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.blue,
                width: 0,
              ),
            ),
            margin: EdgeInsets.only(bottom: 10, left: 20),
            child: Row(
              children: [
                Text("Moderate Stress", style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold, fontSize: 20),)

              ],
            ),
          ),
          Container(
            decoration: new BoxDecoration(
              color: Colors.red,
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.red,
                width: 0,
              ),
            ),
            margin: EdgeInsets.only(bottom: 60, left: 20),
            child: Row(
              children: [
                Text("High Stress", style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold, fontSize: 20),)

              ],
            ),
          ),
          Container(
            padding: EdgeInsets.all(20),
            child: SfLinearGauge(
              minimum: 0,
              maximum: 60,
              markerPointers: [
                LinearShapePointer(
                  value: resultScore.toDouble(),
                  // value: 20,
                ),
              ],
              ranges: <LinearGaugeRange>[
                LinearGaugeRange(startValue: 0, endValue: 22, color: Colors.green,),
                LinearGaugeRange(startValue: 22, endValue: 35, color: Colors.blue,),
                LinearGaugeRange(startValue: 35, endValue: 60, color: Colors.red,),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.all(20,),
            child: Text(resultPhrase, style: TextStyle(fontWeight: FontWeight.bold),),
          ),
          FlatButton(
            child: Text(
              'Restart for testing!',
              style: TextStyle(fontWeight: FontWeight.bold),
            ), //Text
            textColor: Colors.blue,
            onPressed:(){
              resetHandler();
              createscoree();
            }
          ), //FlatButton
        ], //<Widget>[]
      ), //Column
    ); //Center
  }
  void createscoree() async{
    if (isInputsValid()) {
      print(resultScore.toDouble());
      _fireBaseutils.writeMessage("Stress Score", resultScore.toString());
    }

  }
  bool isInputsValid() {
    return (resultScore.toDouble().toString().isNotEmpty);
  }
}