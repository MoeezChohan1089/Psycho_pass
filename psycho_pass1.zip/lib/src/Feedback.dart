import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:psycho_pass/SharedPreference/AppSharedPreference.dart';
import 'package:psycho_pass/Singleton/Singleton.dart';
import 'package:psycho_pass/models/AppUser.dart';
import 'package:psycho_pass/src/FirebaseDatabase.dart';
import 'package:psycho_pass/src/signup.dart';
import 'package:psycho_pass/src/welcomePage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../side-menu.dart';
import 'Widget/bezierContainer.dart';
import 'forgot.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:psycho_pass/Utils/SignInFields.dart';
import 'package:get/get.dart';

class FeedbackPage extends StatefulWidget {
  static final id = '/';
  FeedbackPage({Key key, this.title, this.uid}) : super(key: key);

  final String title;
  final String uid;

  @override
  _FeedbackPageState createState() => _FeedbackPageState(uid);
}

class _FeedbackPageState extends State<FeedbackPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  FlutterLocalNotificationsPlugin localNotification;
  final TextEditingController _userController = TextEditingController();
  final TextEditingController _messageController = TextEditingController();
  bool _autoValidate = false;
  final uid;
  final _auth = FirebaseAuth.instance;
  bool showProgress = false;

  _FeedbackPageState(this.uid);
  Map<dynamic, dynamic> keyValues = {};
  FireBaseutils _fireBaseutils = new FireBaseutils();
  bool _success;
  String _messagefeedback;
  bool isVisible = false;
  Future _showNotification() async{
    var androidDetails = new AndroidNotificationDetails(
        "channelId",
        "Psycho_Pass",
        "Thanks for Feedback We have received.",
        importance: Importance.high);
    var IOSdetails = new IOSNotificationDetails();
    var generalNotificationDetails = new NotificationDetails(android: androidDetails, iOS: IOSdetails);
    await localNotification.show(0,  "Psycho_Pass",
        "Thanks for Feedback We have received.",
        generalNotificationDetails);
  }
  @override
  void initState() {
    super.initState();
    var androidInitialize = new AndroidInitializationSettings('psycho_pass');
    var IOSInitialize = new IOSInitializationSettings();
    var initializationSettings = new InitializationSettings(
        android: androidInitialize, iOS: IOSInitialize);
    localNotification = new FlutterLocalNotificationsPlugin();
    localNotification.initialize(initializationSettings);

  }
  Widget _backButton() {
    return InkWell(
      onTap: () {
        Navigator.pop(context);
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 10),
        child: Row(
          children: <Widget>[
            Container(
              padding: EdgeInsets.only(left: 0, top: 10, bottom: 10),
              child: Icon(Icons.keyboard_arrow_left, color: Colors.black),
            ),
            Text('Back',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500))
          ],
        ),
      ),
    );
  }
  Widget _entryField(

      String title,
      TextEditingController controller, {
        bool isPassword = false, GlobalKey<FormState> key, bool autovalidate, void Function(String val) addValuesInMap, void Function() validateInputs,

      }) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            title,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
          ),
          SizedBox(
            height: 10,
          ),
          TextField(
              keyboardType: TextInputType.emailAddress,
              obscureText: isPassword,
              controller: controller,
              decoration: InputDecoration(
                  border: InputBorder.none,
                  fillColor: Color(0xfff3f3f4),
                  filled: true)),
        ],
      ),
    );
  }

  Widget _createAccountLabel() {
    return InkWell(
      onTap: () {
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => MenuPage()));
      },
      child: Container(
//        margin: EdgeInsets.symmetric(vertical: 10),
//        padding: EdgeInsets.all(15),
        alignment: Alignment.bottomCenter,
      ),
    );
  }

  Widget _emailPasswordWidget() {
    return Column(
      children: <Widget>[
        _entryField("Name", _userController,  key: _formKey, autovalidate: _autoValidate, validateInputs: this._validateInputs, addValuesInMap: this._addValuesInMap,),
        _entryField(
          "Message",
          _messageController,
          key: _formKey,
          autovalidate: _autoValidate,
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return Scaffold(
        body: Container(
          height: height,
          child:Stack(
            children: <Widget>[
              Positioned(
                  top: -height * .15,
                  right: -MediaQuery.of(context).size.width * .4,
                  child: BezierContainer()),
              if (showProgress)
                Center(
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          height: 50,
                          width: 50,
                          child: CircularProgressIndicator(),
                        ),
                      ],
                    ),
                  ),
                )
              else
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        SizedBox(height: height * .2),
                        Image.asset(
                          'images/logo.png',
                          width: 150.0,
                          height: 120.0,
                          fit: BoxFit.cover,
                        ),
                        SizedBox(height: 50),
                        _emailPasswordWidget(),
                        SizedBox(height: 20),
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 6),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.all(Radius.circular(5)),
                              boxShadow: <BoxShadow>[
                                BoxShadow(
                                    color: Colors.grey.shade200,
                                    offset: Offset(2, 4),
                                    blurRadius: 5,
                                    spreadRadius: 2)
                              ],
                              gradient: LinearGradient(
                                  begin: Alignment.centerLeft,
                                  end: Alignment.centerRight,
                                  colors: [
                                    Color(0xfff0876d4),
                                    Color(0xfff0876d4)
                                  ])),
                          child: FlatButton(
                            child: Text(
                              'Submit',
                              style: TextStyle(fontSize: 18.0, color: Colors.white),
                            ),
                            onPressed: () async {
                              if (isInputsValid()) {
                                setState(() {
                                  isVisible = true;
                                });
                                _showNotification();
                                print(_messageController.text);
                                _fireBaseutils.writeMessage(_userController.text, _messageController.text);
                              }
                            },
                          ),
                        ),
                        SizedBox(height: height * .055),
                        _createAccountLabel(),
                      ],
                    ),
                  ),
                ),
              Container(
                alignment: Alignment.center,
                child: Text(_success == null
                    ? ''
                    : (_success
                    ? 'Thanks for feedback ' + _messagefeedback
                    : 'Feedback failed')),
              ),
              Positioned(top: 40, left: 0, child: _backButton()),
            ],
          ),
        ));
  }
  void _validateInputs() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      print(keyValues);
      Navigator.pushNamed(context, MenuPage.id);
    } else {
      setState(() {
        _autoValidate = true;
      });
    }
  }

  // Add Values In Map
  void _addValuesInMap(String val) {
    keyValues[val] = val;
  }
  bool isInputsValid() {
    return (_messageController.value.text.trim().toString().isNotEmpty);
  }
}
