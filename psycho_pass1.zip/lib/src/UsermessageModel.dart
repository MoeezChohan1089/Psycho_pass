class MessageModel{
  String username;
 String message;
 MessageModel(this.username,this.message);

 toJson(){
   return{
     "username": username,
   "message": message
       };
 }
}