import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:psycho_pass/SharedPreference/AppSharedPreference.dart';
import 'package:psycho_pass/Singleton/Singleton.dart';
import 'package:psycho_pass/models/AppUser.dart';
import 'package:psycho_pass/side-menu.dart';
import 'Widget/bezierContainer.dart';
import 'loginPage.dart';

class SignUpPage extends StatefulWidget {
  static final id = "/SignupPage";

  SignUpPage({Key key, this.title, this.uid}) : super(key: key);

  final String title;
  final String uid;

  @override
  _SignUpPageState createState() => _SignUpPageState(uid);
}

class _SignUpPageState extends State<SignUpPage> {
  FlutterLocalNotificationsPlugin localNotification;
  final uid;
  final _formKey = GlobalKey<FormState>();
  FirebaseAuth firebaseAuth = FirebaseAuth.instance;
  DatabaseReference dbRef =
      FirebaseDatabase.instance.reference().child("Users");
  TextEditingController emailController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController pinController = TextEditingController();
  TextEditingController stateController = TextEditingController();
  bool _success;
  String _userEmail;

  _SignUpPageState(this.uid);

  Future _showNotification() async {
    var androidDetails = new AndroidNotificationDetails(
        "channelId", "Psycho_Pass", "Welcome in our App now you can test.",
        importance: Importance.high);
    var IOSdetails = new IOSNotificationDetails();
    var generalNotificationDetails =
        new NotificationDetails(android: androidDetails, iOS: IOSdetails);
    await localNotification.show(0, "Psycho_Pass",
        "Welcome in our App now you can test.", generalNotificationDetails);
  }

  @override
  void initState() {
    super.initState();
    Firebase.initializeApp();
    var androidInitialize = new AndroidInitializationSettings('psycho_pass');
    var IOSInitialize = new IOSInitializationSettings();
    var initializationSettings = new InitializationSettings(
        android: androidInitialize, iOS: IOSInitialize);
    localNotification = new FlutterLocalNotificationsPlugin();
    localNotification.initialize(initializationSettings);
  }

  Widget _backButton() {
    return InkWell(
      onTap: () {
        Navigator.pop(context);
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 10),
        child: Row(
          children: <Widget>[
            Container(
              padding: EdgeInsets.only(left: 0, top: 10, bottom: 10),
              child: Icon(Icons.keyboard_arrow_left, color: Colors.black),
            ),
            Text('Back',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500))
          ],
        ),
      ),
    );
  }

  Widget _entryField(String title, TextEditingController _controller,
      {bool isPassword = false}) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            title,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
          ),
          SizedBox(
            height: 10,
          ),
          TextField(
            obscureText: isPassword,
            controller: _controller,
            decoration: InputDecoration(
              border: InputBorder.none,
              fillColor: Color(0xfff3f3f4),
              filled: true,
            ),
          )
        ],
      ),
    );
  }

  Widget _submitButton() {
    return Container(
      width: MediaQuery.of(context).size.width,
      padding: EdgeInsets.symmetric(vertical: 6),
      alignment: Alignment.center,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(5)),
          boxShadow: <BoxShadow>[
            BoxShadow(
                color: Colors.grey.shade200,
                offset: Offset(2, 4),
                blurRadius: 5,
                spreadRadius: 2)
          ],
          gradient: LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [Color(0xfff0876d4), Color(0xfff0876d4)])),
      child: FlatButton(
        child: Text(
          'Register',
          style: TextStyle(fontSize: 18.0, color: Colors.white),
        ),
        onPressed: () {
          if (isInputsValid()) {
            setState(() {
              isVisible = true;
            });
            _showNotification();
            registerToFb();
          }
        },
      ),
    );
  }

  void registerToFb() async {
    await firebaseAuth
        .createUserWithEmailAndPassword(
            email: emailController.text, password: passwordController.text)
        .then((result) {
      dbRef.child(result.user.uid).set({
        "id":result.user.uid,
        "name": nameController.text,
        "email": emailController.text,
        "password": passwordController.text,
        "phone": phoneController.text,
        "pin": pinController.text,
        "state": stateController.text,
      }).then((res) async {
        await FirebaseDatabase.instance
            .reference()
            .child("Users")
            .child(result.user.uid)
            .once()
            .then((value) async {
              print('${value.key}');
          print('${value.value['name']}');
          print('${value.value['email']}');
          print('${value.value['phone']}');
          print('${value.value['pin']}');
          print('${value.value['state']}');
          AppUser user = new AppUser(
            id: value.key,
            name: value.value['name'],
            email: value.value['email'],
            phone: value.value['phone'],
            pin: value.value['pin'],
            state: value.value['state'],
          );
          Singleton.user = user;
          await AppSharedPref.saveUser('user', user, 'patient');
        });
        Fluttertoast.showToast(
            msg: "Successfully Registered",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.blueAccent,
            textColor: Colors.white,
            fontSize: 16.0);
        Singleton.userId = result.user.uid;
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (context) => MenuPage(
                    uid: result.user.uid,
                  )),
        );
      });
    }).catchError((err) {
      showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text("Error"),
              content: Text(err.message),
              actions: [
                TextButton(
                  child: Text("Ok"),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                )
              ],
            );
          });
    });
    setState(() {
      isVisible = false;
    });
  }

  Widget _loginAccountLabel() {
    return InkWell(
      onTap: () {
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => LoginPage()));
      },
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 20),
        padding: EdgeInsets.all(15),
        alignment: Alignment.bottomCenter,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Already have an account ?',
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
            ),
            SizedBox(
              width: 10,
            ),
            Text(
              'Login',
              style: TextStyle(
                  color: Color(0xfff79c4f),
                  fontSize: 13,
                  fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }

  Widget _emailPasswordWidget() {
    return Column(
      children: <Widget>[
        _entryField("Name", nameController),
        _entryField("Email", emailController),
        _entryField("Password", passwordController, isPassword: true),
        _entryField("Phone Number", phoneController),
        _entryField("Zip Code", pinController),
        _entryField("State", stateController),
      ],
    );
  }

  bool isVisible = false;

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return Scaffold(
      //key: _formKey,
      body: Container(
        height: height,
        child: Stack(
          children: <Widget>[
            Positioned(
              top: -MediaQuery.of(context).size.height * .15,
              right: -MediaQuery.of(context).size.width * .4,
              child: BezierContainer(),
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(height: height * .2),
                    Image.asset(
                      'images/logo.png',
                      width: 150.0,
                      height: 120.0,
                      fit: BoxFit.cover,
                    ),
                    SizedBox(
                      height: 50,
                    ),
                    _emailPasswordWidget(),
                    SizedBox(
                      height: 20,
                    ),
                    _submitButton(),
                    SizedBox(height: height * .14),
                    _loginAccountLabel(),
                  ],
                ),
              ),
            ),
            Container(
              alignment: Alignment.center,
              child: Text(_success == null
                  ? ''
                  : (_success
                      ? 'Successfully registered ' + _userEmail
                      : 'Registration failed')),
            ),
            Positioned(top: 40, left: 0, child: _backButton()),
            Visibility(
              visible: isVisible,
              child: Center(
                child: CircularProgressIndicator(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  bool isInputsValid() {
    return (emailController.value.text.trim().toString().isNotEmpty &&
        nameController.value.text.trim().toString().isNotEmpty &&
        passwordController.value.text.trim().toString().isNotEmpty &&
        phoneController.value.text.trim().toString().isNotEmpty &&
        pinController.value.text.trim().toString().isNotEmpty &&
        stateController.value.text.trim().toString().isNotEmpty);
  }
}
