import 'package:firebase_database/firebase_database.dart';
import 'package:psycho_pass/Singleton/Singleton.dart';
import 'package:psycho_pass/models/AppUser.dart';

class FireBaseutils{
  final dbref = FirebaseDatabase.instance.reference();
  void writeMessage(String username, String message){
    dbref.child("Feedback").push().set(
      {
        'Name': username,
        'Feedback Message': message
      }
    );
  }
}
class FireBaseutilss{
  final AppUser user = Singleton.user;
  final dbref = FirebaseDatabase.instance.reference();
  void writeMessage(String username, String message){
    dbref.child("Users").child(user.id).child('questions').push().set(
        {
          'Question': message
        }
    );
  }
}

class FireBaseutilssocre{
  final AppUser user = Singleton.user;
  final dbref = FirebaseDatabase.instance.reference();
  void writeMessage(String username, String message){
    dbref.child("Patient "+user.name+" Score Anxiety").push().set(
        {
          'Score': message,
        }
    );
  }
}

class FireBaseutilssocree{
  final AppUser user = Singleton.user;
  final dbref = FirebaseDatabase.instance.reference();
  void writeMessage(String username, String message){
    dbref.child("Patient "+user.name+" Score Stress").push().set(
        {
          'Score': message,
        }
    );
  }
}

