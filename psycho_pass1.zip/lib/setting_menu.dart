
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:psycho_pass/change_password.dart';
import 'package:psycho_pass/side-menu.dart';
import 'package:psycho_pass/src/loginPage.dart';

import 'Anxiety/anxiety_test.dart';
import 'Screens/ProfilePage.dart';

class settingMenuPage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        appBar: new AppBar(
          backgroundColor: Colors.blue,
          title: new Text("Settings"),
          elevation: defaultTargetPlatform == TargetPlatform.android ? 5.0:0.0,
          actions: <Widget>[
            InkWell(
              onTap: ()=>  Navigator.push(
                  context, MaterialPageRoute(builder: (context) => MenuPage())),
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Row(
                  children: <Widget>[

                  ],
                ),
              ),
            ),
          ],
        ),
        body:ListView(
          padding: EdgeInsets.all(15),
          children: <Widget>[
            ListTile(
              title: Text('Change Password', style: TextStyle(fontSize: 20),),
              onTap: ()=>  Navigator.push(
                  context, MaterialPageRoute(builder: (context) => changePage())),
            ),
          ],
        ),
    );
  }
}