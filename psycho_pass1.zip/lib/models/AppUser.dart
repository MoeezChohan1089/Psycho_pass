class AppUser {
  String id;
  String name;
  String email;
  String phone;
  String pin;
  String state;
  dynamic questions;
  AppUser({this.id,this.name, this.email, this.phone, this.pin, this.state, this.questions});

  factory AppUser.fromJson(dynamic response) {
    return AppUser(
      id: response['id'],
      name: response['names'],
      email: response['email'],
      phone: response['phone'],
      pin: response['pin'],
      state: response['state'],
      questions: response['questions'],
    );
  }

  Map<String, String> toJson() => {
        'id':id,
        'names': name,
        'email': email,
        'phone': phone,
        'pin': pin,
        'state': state,
    'questions': questions,
      };
}

class AppUser1 {
  String Q1;
  String Q2;
  String Q3;
  String Q4;
  String Q5;
  String Q6;
  String Q7;
  String Q8;
  String Q9;
  String Q10;
  AppUser1({this.Q1, this.Q2, this.Q3, this.Q4, this.Q5, this.Q6, this.Q7, this.Q8, this.Q9, this.Q10});

  factory AppUser1.fromJson(dynamic response) {
    return AppUser1(
      Q1: response['Q1'],
      Q2: response['Q2'],
      Q3: response['Q3'],
      Q4: response['Q4'],
      Q5: response['Q5'],
      Q6: response['Q6'],
      Q7: response['Q7'],
      Q8: response['Q8'],
      Q9: response['Q9'],
      Q10: response['Q10'],
    );
  }

  Map<String, String> toJson() => {
    'Q1':Q1,
    'Q2': Q2,
    'Q3': Q3,
    'Q4': Q4,
    'Q5': Q5,
    'Q6': Q6,
    'Q7': Q7,
    'Q8': Q8,
    'Q9': Q9,
    'Q10': Q10,
  };
}
